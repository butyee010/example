package testOnly;

import java.net.URISyntaxException;
import java.util.Arrays;
import java.util.Map;
import java.util.TreeMap;
import java.util.Map.Entry;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import testOnly.api.bean.bxCurrencyPairing;
import testOnly.api.bx.BxApi;
import testOnly.api.constants.ApiConstants;

public class mainApp {

	public static void main(String[] args) throws InterruptedException, RestClientException, URISyntaxException {

		Map<Integer, bxCurrencyPairing> bxCurrencyPairMap = BxApi.GetApiCurrencyPairings();
	
		for(Entry<Integer, bxCurrencyPairing> item : bxCurrencyPairMap.entrySet()){
			System.out.println("Key: "+item.getKey()+" name:"+item.getValue().getPrimary_currency());
		}
		
	}// end main

}// end class
