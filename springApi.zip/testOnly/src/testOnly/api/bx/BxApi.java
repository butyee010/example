package testOnly.api.bx;
import java.util.Arrays;
import java.util.Map;
import java.util.TreeMap;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import testOnly.api.bean.bxCurrencyPairing;
import testOnly.api.constants.ApiConstants;

public class BxApi {
	
	public static Map<Integer, bxCurrencyPairing> GetApiCurrencyPairings(){
		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		headers.setContentType(MediaType.APPLICATION_JSON);
		headers.add(ApiConstants.USER_AGENT , ApiConstants.CHROME_V_54_0);
		RestTemplate restTemplate = new RestTemplate();
		HttpEntity<String> request = new HttpEntity<>(headers);
		ResponseEntity<String> response = restTemplate.exchange(ApiConstants.url_bx , HttpMethod.GET , request, String.class);
		Map<Integer, bxCurrencyPairing> bxCurrencyPairMap = new Gson().fromJson(response.getBody(), new TypeToken<Map<Integer, bxCurrencyPairing>>(){}.getType());
		return new TreeMap<Integer, bxCurrencyPairing>(bxCurrencyPairMap);
	}
	

}// end class
