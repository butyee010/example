package testOnly.api.bean;

public class Header {
	
	private String reqID;
	private String reqChannel;
	private String reqDtm;
	private String reqBy;
	private String service;
	
	
	
	public Header(String reqID, String reqChannel, String reqDtm, String reqBy, String service) {
		super();
		this.reqID = reqID;
		this.reqChannel = reqChannel;
		this.reqDtm = reqDtm;
		this.reqBy = reqBy;
		this.service = service;
	}
	
	public Header(){
		
	}
	
	public String getReqID() {
		return reqID;
	}
	public void setReqID(String reqID) {
		this.reqID = reqID;
	}
	public String getReqChannel() {
		return reqChannel;
	}
	public void setReqChannel(String reqChannel) {
		this.reqChannel = reqChannel;
	}
	public String getReqDtm() {
		return reqDtm;
	}
	public void setReqDtm(String reqDtm) {
		this.reqDtm = reqDtm;
	}
	public String getReqBy() {
		return reqBy;
	}
	public void setReqBy(String reqBy) {
		this.reqBy = reqBy;
	}
	public String getService() {
		return service;
	}
	public void setService(String service) {
		this.service = service;
	}
	
	
}
