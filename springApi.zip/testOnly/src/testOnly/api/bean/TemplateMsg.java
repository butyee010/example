package testOnly.api.bean;
import testOnly.api.bean.CalculateRTPFeeReq;
import testOnly.api.bean.Header;

public class TemplateMsg {

	private Header headerReq ;
	private CalculateRTPFeeReq calculateRTPFeeReq;
	
	public TemplateMsg(){
		
	}
	
	public TemplateMsg(Header headerReq, CalculateRTPFeeReq calculateRTPFeeReq) {
		super();
		this.headerReq = headerReq;
		this.calculateRTPFeeReq = calculateRTPFeeReq;
	}
	
	public Header getHeaderReq() {
		return headerReq;
	}
	public void setHeaderReq(Header headerReq) {
		this.headerReq = headerReq;
	}
	public CalculateRTPFeeReq getCalculateRTPFeeReq() {
		return calculateRTPFeeReq;
	}
	public void setCalculateRTPFeeReq(CalculateRTPFeeReq calculateRTPFeeReq) {
		this.calculateRTPFeeReq = calculateRTPFeeReq;
	}
	
	
}
