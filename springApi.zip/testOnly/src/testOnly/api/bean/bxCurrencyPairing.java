package testOnly.api.bean;

public class bxCurrencyPairing {

	private String pairing_id;
	private String primary_currency;
	private String secondary_currency;
	
	public String getPairing_id() {
		return pairing_id;
	}
	public void setPairing_id(String pairing_id) {
		this.pairing_id = pairing_id;
	}
	public String getPrimary_currency() {
		return primary_currency;
	}
	public void setPrimary_currency(String primary_currency) {
		this.primary_currency = primary_currency;
	}
	public String getSecondary_currency() {
		return secondary_currency;
	}
	public void setSecondary_currency(String secondary_currency) {
		this.secondary_currency = secondary_currency;
	}
	
	
}
