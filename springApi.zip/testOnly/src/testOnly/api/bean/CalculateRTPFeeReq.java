package testOnly.api.bean;

public class CalculateRTPFeeReq {
	
	private String fromAnyID;
	private String fromAnyIDType;
	private String toAnyID;
	private String toAnyIDType;
	private String amt;
	private String noOfTxn;
	
	public CalculateRTPFeeReq(){
		
	}
	
	public CalculateRTPFeeReq(String fromAnyID, String fromAnyIDType, String toAnyID, String toAnyIDType, String amt,
			String noOfTxn) {
		super();
		this.fromAnyID = fromAnyID;
		this.fromAnyIDType = fromAnyIDType;
		this.toAnyID = toAnyID;
		this.toAnyIDType = toAnyIDType;
		this.amt = amt;
		this.noOfTxn = noOfTxn;
	}
	public String getFromAnyID() {
		return fromAnyID;
	}
	public void setFromAnyID(String fromAnyID) {
		this.fromAnyID = fromAnyID;
	}
	public String getFromAnyIDType() {
		return fromAnyIDType;
	}
	public void setFromAnyIDType(String fromAnyIDType) {
		this.fromAnyIDType = fromAnyIDType;
	}
	public String getToAnyID() {
		return toAnyID;
	}
	public void setToAnyID(String toAnyID) {
		this.toAnyID = toAnyID;
	}
	public String getToAnyIDType() {
		return toAnyIDType;
	}
	public void setToAnyIDType(String toAnyIDType) {
		this.toAnyIDType = toAnyIDType;
	}
	public String getAmt() {
		return amt;
	}
	public void setAmt(String amt) {
		this.amt = amt;
	}
	public String getNoOfTxn() {
		return noOfTxn;
	}
	public void setNoOfTxn(String noOfTxn) {
		this.noOfTxn = noOfTxn;
	}
	
	
}
