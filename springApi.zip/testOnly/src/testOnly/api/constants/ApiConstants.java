package testOnly.api.constants;

public class ApiConstants {

	public static String url_bx = "https://bx.in.th/api/pairing/";
	public static String url_calFee = "http://10.9.168.122:7079/AnyIDESBRtp/service";
	
	public static String USER_AGENT = "user-agent";
	public static String CHROME_V_54_0 = "Chrome/54.0.2840.99";
	
}
