package testOnly;

import java.util.Arrays;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import testOnly.api.bean.CalculateRTPFeeReq;
import testOnly.api.bean.Header;
import testOnly.api.bean.TemplateMsg;

public class example {

	/*public static TemplateMsg setServiceCalfee(){
		Header header = new Header( "1234567890", "INET-BANK" , "2017-10-19 14:57:00.00" , "00000" , "calculateRTPFee");
		CalculateRTPFeeReq calculateRTPFeeReq = new CalculateRTPFeeReq(
													"1922497062",
													"NATID",
													"0861234510",
													"MSISDN",
													"100.12",
													"1");
		TemplateMsg TemplateMsg = new TemplateMsg(header , calculateRTPFeeReq);
		return TemplateMsg;
	}
	
	public static String postMethodExample(){
		TemplateMsg templateMsg = setServiceCalfee();
		String jsonMsg = objectToJson(templateMsg);
		
		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		headers.setContentType(MediaType.APPLICATION_JSON);
		
		HttpEntity<String> request = new HttpEntity<>(jsonMsg, headers);
		RestTemplate restTemplate = new RestTemplate();
		ResponseEntity<String> response = restTemplate.exchange(url_calFee, HttpMethod.POST , request , String.class);
		
		return response.getBody();
	}
	
	public static String getMethodExample(){
		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		headers.setContentType(MediaType.APPLICATION_JSON);
		headers.add("user-agent", "Chrome/54.0.2840.99");
		RestTemplate restTemplate = new RestTemplate();
		HttpEntity<String> request = new HttpEntity<>(headers);
		ResponseEntity<String> response = restTemplate.exchange(url_bx, HttpMethod.GET , request, String.class);
		return response.getBody();
	}*/
	
}
