package testOnly.utility;

import com.google.gson.Gson;

public class commons {

	
	public static String objectToJson(Object request) {
		return new Gson().toJson(request);
	}
	
	public static Object jsonToObject(String jsonMsg , Class<?> clazz){
		return new Gson().fromJson(jsonMsg, clazz);
	}
	
	public static int compare(Integer o1, Integer o2) {
        return o2.compareTo(o1);
    }
	
}

