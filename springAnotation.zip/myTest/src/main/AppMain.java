package main;


import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import config.Configuare;
import engine.MyThread;

public class AppMain {
	
	public static AnnotationConfigApplicationContext ctx;
	public static void main(String[] args){
		initialize();
		MyThread t = (MyThread) ctx.getBean("MyThread");
		t.exec();
		ctx.close();
		System.out.println("END");
	}
	
	public static void initialize(){
		ctx = new AnnotationConfigApplicationContext();
		ctx.register(Configuare.class);
		ctx.refresh();
		String[] listBeans = ctx.getBeanDefinitionNames();
		for (String b : listBeans) {
			System.out.println("Bean-name: " + b);
		}
	}
}
