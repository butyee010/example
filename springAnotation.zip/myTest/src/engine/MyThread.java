package engine;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import helper.HelloWorldService;

@Service("MyThread")
public class MyThread {
	
	@Autowired
	private HelloWorldService helloWorld;
	
	public void exec(){
		//System.out.println("helloWorld "+helloWorld);
		helloWorld.printHello();
	}
	
}
