package helper;

public interface HelloWorldService {
	
	public void printHello();
}
