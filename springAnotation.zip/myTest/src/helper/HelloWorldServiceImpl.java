package helper;

import org.springframework.stereotype.Component;

@Component
public class HelloWorldServiceImpl implements HelloWorldService {

	@Override
	public void printHello() {
		System.out.println("Hello World");
	}

	
}
