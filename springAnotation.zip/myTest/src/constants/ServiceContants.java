package constants;

public class ServiceContants {
	
	public final static String BEAN_ID_TASK_EXECUTOR = "taskExecutor";
	
}
