package springApp;

import java.util.Date;

import org.springframework.scheduling.TriggerContext;

public interface Trigger {
	
	Date nextExecutionTime(TriggerContext triggerContext);
	
}
