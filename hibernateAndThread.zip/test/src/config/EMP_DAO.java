package config;

import org.hibernate.Session;

import entity.Employee;

public class EMP_DAO extends DAO{
	
	private Session session = null;
	
	public void addEmployee(Employee employee , ThreadLocal<Session> threadSession){
		try{
			session = SessionFactoryUtil.currentSession(threadSession);
			session.saveOrUpdate(employee);
			session.flush();
		}catch (Exception e) {
			e.printStackTrace();
		}finally {
			try {
				SessionFactoryUtil.closeSession(session);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
	
	/*String sql = "SELECT * FROM FORTEST.EMPLOYEE";
	Query query = session.createSQLQuery(sql);
	query.setMaxResults(1);
	Object[] result = (Object[])query.uniqueResult();
	System.out.println("result "+result);*/
}
