package config;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnection {
	
	private static String driverDB2 = "com.ibm.db2.jcc.DB2Driver";
	private static String urlDB2 = "jdbc:db2://localhost:50000/BPMDB";
	private static String user = "admin";
	private static String password = "admin";
	
	public static Connection getConnection(){
		return bindingConnection();
	}
	
	
	private static Connection bindingConnection(){
		try {
			Class.forName(driverDB2);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		try {
			return DriverManager.getConnection(urlDB2, user, password);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}
	
	public static void close(Object obj){
		try {
			if(obj != null){
				obj.getClass().getMethod("close", Object.class).invoke(obj);				
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
}
