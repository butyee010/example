package config;

import org.hibernate.Session;

public abstract class ThreadFactory implements Runnable{
	
	protected ThreadLocal<Session> session = new ThreadLocal<Session>();
	
	public ThreadFactory(){
		
	}
	
	@Override
	public void run(){
		execute();
	}

	public abstract void begin();
	
	
	public abstract void execute();

	public void sleep(int time){
		try {
			Thread.sleep(time);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}		
	}
}
