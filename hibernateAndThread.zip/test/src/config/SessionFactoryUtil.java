package config;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;


public class SessionFactoryUtil {

	private static final SessionFactory sessionFactory;
	
	private static final ThreadLocal<Session> session = new ThreadLocal<Session>();
	
	private static final ThreadLocal<Transaction> transaction = new ThreadLocal<Transaction>();

	static {
		try {
			sessionFactory = new Configuration().configure("/hibernate.cfg.xml").buildSessionFactory();
		} catch (Throwable ex) {
			// Log the exception.
			System.err.println("Initial SessionFactory creation failed." + ex);
			throw new ExceptionInInitializerError(ex);
		}
	}

	public static Session currentSession() throws HibernateException {
		Session s = (Session) session.get();
		if (s == null || !s.isConnected()) {
			s = sessionFactory.openSession();
			session.set(s);
		}
		beginTransaction(s);
		return s;
	}
	
	public static Session currentSession(ThreadLocal<Session> threadSession) throws HibernateException {
		Session s = (Session) threadSession.get();
		if (s == null || !s.isConnected()) {
			s = sessionFactory.openSession();
			threadSession.set(s);
		}
		beginTransaction(s);
		return s;
	}
	
	public static void beginTransaction(Session session) throws HibernateException {
		
		Transaction tx = (Transaction) transaction.get();
		if (tx == null) {
			tx = session.beginTransaction();
			transaction.set(tx);
		}
	}
	
	public static Transaction getCurrentTransaction() throws HibernateException {
		return transaction.get();
	}
	
	public static void clearTransaction(){
		transaction.remove();
	}
	
	public static Session openSession(){
		Session s = sessionFactory.openSession();
		beginTransaction(s);
		return s;
	}
	
	public static void rollbackTransaction() throws HibernateException {
        Transaction tx = (Transaction) transaction.get();
        try {
        	transaction.set(null);
            if ( tx != null) {
                tx.rollback();
            }
        } finally {
            closeSession();
        }
    }
	
	public static void commitTransaction() throws HibernateException {
		Transaction tx = (Transaction) transaction.get();
		if (tx != null) {
			tx.commit();
		}
		transaction.set(null);
	}

	public static void closeSession() throws HibernateException {
		Session s = (Session) session.get();
		session.set(null);
        if (s != null && s.isOpen()) {
            s.close();
        }
        clearTransaction();
	}
	
	public static void closeSession(Session session) throws HibernateException {
        if (session != null && session.isOpen()) {
        	session.close();
        }
        clearTransaction();
	}
	
	public static void closeFactory(){
		if(sessionFactory != null && sessionFactory.isOpen()){
			sessionFactory.close();
		}
	}
	
	
}
