package util;

import java.util.Random;

public class RandomUtil {
	
	public static String randomString(){
		Random gen = new Random();
		char c = (char) (gen.nextInt(26) + 'A');
		return new String(String.valueOf(c));
	}
	
	public static String randomNumber(){
		Random gen = new Random();
		return new String(String.valueOf(gen.nextInt(10)));
	}
}
