package main;

import java.util.Calendar;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import builderConstants.Constant;
import event.EmpThread;

public class engine {

	public static void main(String[] args){
		
		Calendar a = Calendar.getInstance();
		System.out.println(a.getTime().getTime());
		
		/*ExecutorService executor = Executors.newFixedThreadPool(Constant.MAX_THREAD);
		System.out.println("start ");
		
	
		for(int i=0; i<30; i++){
			EmpThread threadRunnable = new EmpThread(); 
			executor.execute(threadRunnable);
		}
		executor.shutdown();*/
		/*try {
			Thread.sleep(7000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
		/*while(true){
			Thread.sleep(10000);
		}
		try {
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		System.out.println("close ");*/
		//SessionFactoryUtil.closeFactory();
		//System.exit(1);
	}
}
