package builderConstants;

public class Constant {
	public static int MAX_THREAD = 30;
}
