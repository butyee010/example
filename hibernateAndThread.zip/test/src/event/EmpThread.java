package event;

import config.EMP_DAO;
import config.ThreadFactory;
import entity.Employee;
import helper.EngineHelper;
import util.RandomUtil;

public class EmpThread extends ThreadFactory{
	private static int count = 1;
	private EMP_DAO empDao = new EMP_DAO();
	
	@Override
	public void begin() {}

	@Override
	public void execute() {
		Employee employee = new Employee();
		employee.setCode(EngineHelper.gerenateCode());
		employee.setFname(RandomUtil.randomString()+RandomUtil.randomString());
		employee.setLname(RandomUtil.randomString()+RandomUtil.randomString());
		empDao.addEmployee(employee , session);			
		System.out.println("count: "+(count++)+" code: "+employee.getCode()+" first name: "+employee.getFname()+" last name: "+employee.getLname());
	}

}
