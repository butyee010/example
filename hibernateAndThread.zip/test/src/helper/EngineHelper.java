package helper;

import util.RandomUtil;

public class EngineHelper {
	
	public static String gerenateCode(){
		String pos1 = RandomUtil.randomString();
		String pos2 = RandomUtil.randomString();
		String pos3 = RandomUtil.randomString();
		String pos4 = RandomUtil.randomNumber();
		return pos1+pos2+pos3+pos4;
	}
	
}
